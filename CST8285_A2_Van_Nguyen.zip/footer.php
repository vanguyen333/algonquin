<footer>
        <p>&copy; <?php echo date("Y");?>  CST8285.
        <a href = "https://www.tutorialrepublic.com/php-tutorial/php-mysql-crud-application.php">
            Updated educational version based on tutorialrepublic CRUD sample
            </a>
        </p>
    
    </footer>